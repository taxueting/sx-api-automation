import pytest
import os

from interface.business.search_management import format_mongo_data, compare_two_list_plates, \
    get_device_name, get_start_time, get_end_time
from interface.business.search_management import format_scrapy_data
from interface.business.search_management import get_all_data
from utils.excel import write_excel_xls_append


class TestAccuracyPlates(object):
    def setup_class(self):
        self.one_plates_gt, self.two_plates_gt, self.three_plates_gt = format_mongo_data()
        self.one_plates_pt, self.two_plates_pt, self.three_plates_pt = format_scrapy_data(get_all_data())
        self.values = []
        self.values.extend([get_device_name(), get_start_time() + "-" + get_end_time(), len(self.one_plates_gt),
                            len(self.two_plates_gt),
                            len(self.three_plates_gt), len(self.one_plates_pt), len(self.two_plates_pt),
                            len(self.three_plates_pt)])

    def teardown_class(self):
        """
        完成了之后写入excel数据
        :return:
        """
        tmp = self.values[0:8]
        data = self.values[-6:]
        for index, value in enumerate(data):
            if index % 2 == 0:
                tmp.append(value)

        for index, value in enumerate(data):
            if index % 2 == 1:
                tmp.append(value)
        values = [tmp]
        book_name_xls = os.path.dirname(
            os.path.dirname(os.path.dirname(os.getcwd()))) + os.sep + 'data' + os.sep + 'accuracy_test.xls'
        write_excel_xls_append(book_name_xls, values)

    def test_compare_one_plates(self):
        count = 0
        if len(self.one_plates_gt) == 0:
            self.values.append(count)
            return
        count = compare_two_list_plates(self.one_plates_gt, self.one_plates_pt)
        self.values.append(count)

    def test_compare_two_plates(self):
        count = 0
        if len(self.two_plates_gt) == 0:
            self.values.append(0)
            return
        count = compare_two_list_plates(self.two_plates_gt, self.two_plates_pt)
        self.values.append(count)

    def test_compare_three_plates(self):
        count = 0
        if len(self.three_plates_gt) == 0:
            self.values.append(count)
            return
        count = compare_two_list_plates(self.three_plates_gt, self.three_plates_pt)
        self.values.append(count)


