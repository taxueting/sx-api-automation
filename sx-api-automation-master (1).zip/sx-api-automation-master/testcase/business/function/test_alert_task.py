import time
import allure
from testcase.business.function.task_init import *
import pytest
from interface.business import task_management
from utils.query import query_device_id, get_payload_from_mongo

pytestmark = pytest.mark.parametrize('task_name, device_name, incidentType', get_authorized_task_config())


class Test_alert_task:
    def setup_class(self):
        self.TaskManage = task_management.TaskManagement()

    def test_create_task(self, task_name, device_name, incidentType):
        allure.dynamic.title(f'create task: {task_name}')
        request_body = get_payload_from_mongo(device_name)
        request_body["taskName"] = task_name
        request_body = task_add_config(request_body, query_device_id(device_name), sub_zone_id_inited()[0])
        resp, url = self.TaskManage.add_task(**request_body)
        allure.attach(logging_info(resp, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp["content"][
                   "message"] == "success", f"create {task_name} task failed,\nreason:{resp['content']['message']} "
        time.sleep(20)

    def test_task_alert(self, body_alert, task_name, device_name, incidentType):
        allure.dynamic.title(f'alert with task: {task_name}')
        time.sleep(10)
        request_body = body_alert
        request_body = task_query_alert_config(request_body, query_device_id(device_name), incidentType)
        resp, url = self.TaskManage.query_alert(**request_body)
        allure.attach(logging_info(resp, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp["content"]["data"][
                   "total"] > 0, f"task {task_name} query no alert,\nreason:{resp['content']['message']}"
        allure.attach(pic_url_alert(resp), 'alert', allure.attachment_type.URI_LIST)

    def test_task_search_center(self, body_search, task_name, device_name, incidentType):
        allure.dynamic.title(f'search with task: {task_name}')
        time.sleep(10)
        request_body = body_search
        request_body = task_query_search_center_config(request_body, query_device_id(device_name), incidentType)
        resp, url = self.TaskManage.query_search_center(**request_body)
        allure.attach(logging_info(resp, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp["content"]["data"]["searchList"][0][
                   "total"] > 0, f"task {task_name} search no alert,\nreason:{resp['content']['message']}"
        allure.attach(pic_url_search(resp), 'alert_pic', allure.attachment_type.URI_LIST)
