import time
import allure
from testcase.business.function.task_init import *
import pytest
from interface.business import task_management
from utils.query import query_device_id, query_task_id, get_payload_from_mongo

pytestmark = pytest.mark.parametrize('task_name, device_name, incidentType',
                                     [('Non-motor_Vehicle_Attribute_Recognition', 'car_motor', 'OBJECT_HUMAN_POWERED_VEHICLE')])


@pytest.mark.skipif(condition='Non-motor Vehicle Attribute Recognition ' not in get_hard_dog_tasks(),reason='硬狗未授权该任务')
class Test_motor_attr_task:
    def setup_class(self):
        self.TaskManage = task_management.TaskManagement()

    def test_create_motor_attr_task(self, task_name, device_name, incidentType):
        allure.dynamic.title(f'create task: {task_name}')
        request_body = get_payload_from_mongo(device_name)
        request_body["taskName"] = task_name
        assert sub_zone_id_inited() is not  None, f"sub zone not initialized"
        task_add_config(request_body, query_device_id(device_name), sub_zone_id_inited()[0])
        resp, url = self.TaskManage.add_task(**request_body)
        allure.attach(logging_info(resp, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp["content"][
                   "message"] == "success", f"create {task_name} task failed,\nreason:{resp['content']['message']} "
        time.sleep(30)

    def test_motor_attr_task_search_center(self, body_attr_search, task_name, device_name, incidentType):
        allure.dynamic.title(f'search with task: {task_name}')
        time.sleep(30)
        request_body = body_attr_search
        request_body = task_attr_query_search_center_config(request_body, query_device_id(device_name), incidentType)
        resp, url = self.TaskManage.query_search_center(**request_body)
        allure.attach(logging_info(resp, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp["content"]["data"]["searchList"][0][
                   "total"] > 0, f"task {task_name} search no alert,\nreason:{resp['content']['message']}"
        allure.attach(pic_url_search(resp), 'alert_pic', allure.attachment_type.URI_LIST)
