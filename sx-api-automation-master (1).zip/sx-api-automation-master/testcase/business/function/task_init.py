import json
from utils.query import mysql_select_one, date_range
from utils.query_server_info import query_server_info
from interface.business import task_management
from config.business.task_config import task_configs


def task_add_config(Request_body, device_id, sub_zone_id):
    Request_body["deviceTaskConfigs"][0]["deviceId"] = device_id
    Request_body["deviceTaskConfigs"][0]["zoneId"] = sub_zone_id
    Request_body["deviceTaskConfigs"][0]["roiData"] = json.loads(Request_body["deviceTaskConfigs"][0]["roiData"])
    Request_body["deviceTaskConfigs"][0]["roiData"]["id"] = str(device_id)
    Request_body["deviceTaskConfigs"][0]["roiData"]["deviceId"] = str(device_id)
    Request_body["deviceTaskConfigs"][0]["roiData"]["zoneId"] = str(sub_zone_id)
    Request_body["deviceTaskConfigs"][0]["roiData"] = json.dumps(Request_body["deviceTaskConfigs"][0]["roiData"])
    return Request_body


def task_query_search_center_config(Request_body, device_id, incidentTypes):
    Request_body["deviceIdList"][0] = device_id
    Request_body["incidentTypeSearchRequest"]["incidentTypes"][0] = incidentTypes
    Request_body["dateStart"] = date_range()[0]
    Request_body["dateEnd"] = date_range()[1]
    return Request_body


def task_attr_query_search_center_config(Request_body, device_id, featureType):
    Request_body["deviceIdList"][0] = device_id
    Request_body["dateStart"] = date_range()[0]
    Request_body["dateEnd"] = date_range()[1]
    Request_body["attributesSearchRequest"]["featureList"][0]["featureType"]=featureType
    return Request_body

def task_query_alert_config(Request_body, device_id, incidentTypes):
    Request_body["deviceIds"][0] = device_id
    Request_body["incidentTypes"][0] = incidentTypes
    Request_body["dateStart"] = date_range()[0]
    Request_body["dateEnd"] = date_range()[1]
    return Request_body


def pic_url_search(resp):
    url = 'https://' + query_server_info()[1] + resp["content"]["data"]["searchList"][0]["list"][0]["captureUrl"]
    return url


def pic_url_alert(resp):
    url = 'https://' + query_server_info()[1] + resp["content"]["data"]["list"][0]["panoramicImage"]
    return url


def logging_info(resp, url, request_body):
    return f"\nTrace_id is: {resp['headers']['Trace-Id']}\nUrl is: {url}\nRequest_body is: {request_body}"


def device_group_id():
    sql = "SELECT group_id  from info_device_group  where name = 'autotest'"
    return mysql_select_one(sql)


def sub_zone_id_inited():
    sql = "SELECT id  from map_zone mz where name = 'autotest' "
    return mysql_select_one(sql)


def portrait_group_id():
    sql = "SELECT lib_id  from portrait_lib where name = 'autotest_portrait_group' "
    return mysql_select_one(sql)


def body_group_id():
    sql = "SELECT lib_id  from portrait_lib where name = 'autotest_body_group' "
    return mysql_select_one(sql)


def vehicle_group_id():
    sql = "SELECT lib_id  from product_lib where name = 'autotest_vehicle_group' "
    return mysql_select_one(sql)


def get_hard_dog_tasks():
    te = task_management.TaskManagement()
    resp, url = te.query_hard_dog()
    list_task = []
    for task_type in resp["content"]["data"][1]["subPermissions"]:
        for task in task_type['subPermissions']:
            list_task.append(task['name'])
    return list_task


def get_authorized_task_config():
    hard_dog_task_list = get_hard_dog_tasks()
    all_task_list = list(task_configs.keys())
    authorized_task_config = []
    res = set(all_task_list).intersection(hard_dog_task_list)
    for task_name in res:
        if type(task_configs[task_name]) != list:
            authorized_task_config.append(task_configs[task_name])
        else:
            for i in range(len(task_configs[task_name])):
                authorized_task_config.append(task_configs[task_name][i])
    return authorized_task_config

