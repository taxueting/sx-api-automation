import time
import pytest
import allure
from pytest_assume.plugin import assume
from interface.business import device_management
from config.server_info import server_info,file_path
from utils.query import read_config, query_payload, mysql_select_one
from testcase.business.function.task_init import logging_info


class Test_init_devices:

    def setup_class(self):
        self.device_names = read_config(file_path)
        self.host_info = server_info.get('ffserver_info')
        self.request_body_add_group = query_payload('add_group')
        self.request_body_add_device = query_payload('add_device')
        self.DeviceManage = device_management.DeviceManagement()

    @pytest.mark.run(order=8)
    def test_add_device_group(self, root_group_id):
        request_body = self.request_body_add_group
        request_body["parentId"] = root_group_id
        resp, url = self.DeviceManage.add_device_group(**request_body)
        assert resp['content'][
                   'message'] == 'success', f"add device group failed,request body is :{request_body},\nurl is {url},\nreason:{resp['content']['message']}"
        allure.attach(logging_info(resp, url, request_body), 'log', allure.attachment_type.TEXT)

    @pytest.fixture
    def group_id(self):
        sql = "SELECT group_id  from info_device_group where name ='autotest'"
        return mysql_select_one(sql)

    @pytest.mark.run(order=9)
    def test_add_devices(self, group_id):
        request_body = self.request_body_add_device
        for device in self.device_names:
            request_body["deviceName"] = device
            request_body["groupId"] = group_id[0]
            request_body["rtspConfig"][
                "rtspAddress"] = f"rtsp://root:Goodsense@2021@{self.host_info['host']}:554/{device}"
            resp, url = self.DeviceManage.device_add(**request_body)
            assume(resp['content'][
                       'message'] == 'success',
                   f"add devices failed,request body is:{request_body},reason:{resp['content']['message']}")
            allure.attach(logging_info(resp, url, request_body), 'log', allure.attachment_type.TEXT)
            time.sleep(5)
        time.sleep(100)