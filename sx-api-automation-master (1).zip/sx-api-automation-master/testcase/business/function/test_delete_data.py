import time
import allure
import pytest
from interface.business import task_management, map_management, device_management,portrait_management
from utils.query import query_task_name, delete_task, query_IdList, delete_device
from task_init import sub_zone_id_inited,portrait_group_id,body_group_id,vehicle_group_id,logging_info,device_group_id


class Test_delete_data:

    def setup_class(self):
        self.task_ids = delete_task()
        self.device_ids = query_IdList()
        self.TaskManage = task_management.TaskManagement()
        self.MapManage = map_management.MapManagement()
        self.DeviceManage = device_management.DeviceManagement()
        self.PortraitManage = portrait_management.PortraitManagement()

    @pytest.mark.run(order=1)
    def test_delete_tasks(self):
        pytest.mark.skipif(condition=not delete_task(), reason='query no tasks,skip!')
        for task_id in self.task_ids:
            resp, url = self.TaskManage.delete_task(task_id)
            assert resp["content"][
                       "message"] == "success", f"delete task {query_task_name(task_id)} failed,\nreason:{resp['content']['message']}"
            allure.attach(logging_info(resp, url, []), 'log', allure.attachment_type.TEXT)

    @pytest.mark.run(order=2)
    @pytest.mark.skipif(condition=sub_zone_id_inited() is None, reason='query no map,skip!')
    def test_delete_map_zone(self):
        resp, url = self.MapManage.delete_map_zone(sub_zone_id_inited()[0])
        assert resp["content"][
                   "message"] == "success", f"delete autotest map failed,\nreason:{resp['content']['message']}"
        allure.attach(logging_info(resp, url, []), 'log', allure.attachment_type.TEXT)

    @pytest.mark.run(order=3)
    def test_delete_devices(self):
        pytest.mark.skipif(condition=not self.device_ids, reason='query no devices,skip!')
        for device_id in self.device_ids:
            time.sleep(1)
            delete_device(device_id)
        time.sleep(60)
        assert not query_IdList(), f"part device delete failed"

    @pytest.mark.run(order=4)
    @pytest.mark.skipif(condition=device_group_id() is None, reason='query no devices,skip!')
    def test_delete_device_group(self):
        resp, url = self.DeviceManage.device_group_delete(device_group_id()[0])
        assert resp["content"][
                   "message"] == "success", f"delete device group failed,\nreason:{resp['content']['message']}"
        allure.attach(logging_info(resp, url, []), 'log', allure.attachment_type.TEXT)

    @pytest.mark.run(order=5)
    @pytest.mark.skipif(condition=portrait_group_id() is None, reason='query no portrait group,skip!')
    def test_delete_portrait_group(self):
        resp, url = self.PortraitManage.delete_portrait_group(portrait_group_id()[0])
        assert resp["content"][
                   "message"] == "success", f"delete portrait group failed,\nreason:{resp['content']['message']}"
        allure.attach(logging_info(resp, url, []), 'log', allure.attachment_type.TEXT)
        time.sleep(20)

    @pytest.mark.run(order=6)
    @pytest.mark.skipif(condition=body_group_id() is None, reason='query no body group,skip!')
    def test_delete_body_group(self):
        resp, url = self.PortraitManage.delete_body_group(body_group_id()[0])
        assert resp["content"][
                   "message"] == "success", f"delete body group failed,\nreason:{resp['content']['message']}"
        allure.attach(logging_info(resp, url, []), 'log', allure.attachment_type.TEXT)
        time.sleep(20)

    @pytest.mark.run(order=7)
    @pytest.mark.skipif(condition=vehicle_group_id() is None, reason='query no vehicle group,skip!')
    def test_delete_vehicle_group(self):
        resp, url = self.PortraitManage.delete_vehicle_group(vehicle_group_id()[0])
        assert resp["content"][
                   "message"] == "success", f"delete vehicle group failed,\nreason:{resp['content']['message']}"
        allure.attach(logging_info(resp, url, []), 'log', allure.attachment_type.TEXT)
        time.sleep(20)
