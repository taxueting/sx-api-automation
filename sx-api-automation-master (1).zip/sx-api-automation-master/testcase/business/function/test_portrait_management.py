import json

import allure
import pytest
import logging
from config.server_info import portrait_pic, body_pic
from utils.query import query_payload, image_base64
from interface.business import portrait_management
from task_init import portrait_group_id, body_group_id, vehicle_group_id, logging_info

logging.basicConfig(level=logging.DEBUG)


@allure.feature("人像模块")
class Test_portrait_management:

    def setup_class(self):
        self.portrait_base64_code = image_base64(portrait_pic)
        self.body_base64_code = image_base64(body_pic)
        self.request_body_add_portrait = query_payload('add_portrait')
        self.request_body_add_body = query_payload('add_body')
        self.request_body_add_vehicle = query_payload('add_vehicle')
        self.PortraitManage = portrait_management.PortraitManagement()

    @pytest.mark.run(order=14)
    @allure.story("添加人脸库")
    def test_add_portrait_group(self):
        request_body = {"name": "autotest_portrait_group"}
        resp_add, url = self.PortraitManage.add_portrait_group(**request_body)
        allure.attach(logging_info(resp_add, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp_add["content"][
                   "message"] == "success", f"add portrait_group failed,request body is :{request_body},\nreason:{resp_add['content']['message']} "

    @pytest.mark.run(order=15)
    @allure.story("添加人脸")
    def test_add_portrait(self,Logger):
        request_body = self.request_body_add_portrait
        request_body["name"] = 'auto_portrait'
        request_body["libIds"] = [portrait_group_id()[0]]
        request_body["images"] = [self.portrait_base64_code]
        resp_add, url = self.PortraitManage.add_portrait(**request_body)
        allure.attach(logging_info(resp_add, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp_add["content"][
                   "message"] == "success", f"add portrait failed,\nreason:{resp_add['content']['message']} "

    @pytest.mark.run(order=16)
    @allure.story("添加人体库")
    def test_add_body_group(self):
        request_body = {"name": "autotest_body_group"}
        resp_add, url_add = self.PortraitManage.add_body_group(**request_body)
        allure.attach(logging_info(resp_add, url_add, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp_add["content"][
                   "message"] == "success", f"add body_group failed,request body is :{request_body},\nreason:{resp_add['content']['message']} "

    @pytest.mark.run(order=17)
    @allure.story("添加人体")
    def test_add_body(self, Logger):
        request_body = self.request_body_add_portrait
        request_body["name"] = 'auto_body'
        request_body["libIds"] = [body_group_id()[0]]
        request_body["images"] = [self.body_base64_code]
        resp_add, url = self.PortraitManage.add_body(**request_body)
        allure.attach(logging_info(resp_add, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp_add["content"][
                   "message"] == "success", f"add body_group failed,\nreason:{resp_add['content']['message']}"

    @pytest.mark.run(order=18)
    @allure.story("添加车辆库")
    def test_add_vehicle_group(self):
        request_body = {"name": "autotest_vehicle_group"}
        resp_add, url = self.PortraitManage.add_vehicle_group(**request_body)
        allure.attach(logging_info(resp_add, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp_add["content"][
                   "message"] == "success", f"\nadd vehicle_group failed,\nreason:{resp_add['content']['message']} "

    @pytest.mark.run(order=19)
    @allure.story("添加车辆")
    def test_add_vehicle(self):
        request_body = self.request_body_add_vehicle
        request_body["libIds"] = [vehicle_group_id()[0]]
        request_body["automobileLibs"][0]["libId"] = vehicle_group_id()[0]
        resp_add, url = self.PortraitManage.add_vehicle(**request_body)
        allure.attach(logging_info(resp_add, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp_add["content"][
                   "message"] == "success", f"\nadd vehicle failed,\nreason:{resp_add['content']['message']},\ntrace_id is: {resp_add['headers']['Trace-Id']} "
