import pytest
from config.server_info import log_path
from utils.mysql import Mysql
from utils.query import query_payload,query_root_user_info
from utils.logger import logger_handler


@pytest.fixture(scope='session')
def root_group_id():
    sql = f"SELECT group_id  from info_device_group idg where remark ='root' and tenant_id = '{query_root_user_info()[1]}'"
    with Mysql() as mysql:
        query_result = mysql.select_one(sql)
    return query_result[0]


@pytest.fixture(scope='session')
def entire_zone_id():
    sql = "SELECT id  from map_zone mz where parent_id =0 "
    with Mysql() as mysql:
        query_result = mysql.select_one(sql)
    return query_result[0]


@pytest.fixture(scope='session')
def body_alert():
    return query_payload('query_alert')


@pytest.fixture(scope='session')
def body_search():
    return query_payload('query_search_center')


@pytest.fixture(scope='session')
def body_attr_search():
    return query_payload('attr_search_center')


@pytest.fixture(scope='session')
def Logger():
    logger = logger_handler(log_file_path=log_path)
    return logger



