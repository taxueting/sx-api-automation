import json
import time
import allure
from testcase.business.function.task_init import *
import pytest
from interface.business import task_management
from utils.query import query_device_id, query_task_id, query_payload, get_payload_from_mongo

pytestmark = pytest.mark.parametrize('task_name, device_name, incidentType',
                                     [('Face_matched', 'matched_face_comparison', 'FACE_MATCH'),
                                      ('Unmatched_face_comparison', 'unmatched_face_comparison',
                                       'INCIDENT_FACE_UNMATCHED')])


@pytest.mark.skipif(condition='Face Comparison' not in get_hard_dog_tasks(), reason='硬狗未授权该任务')
class Test_face_compare_task:
    def setup_class(self):
        self.TaskManage = task_management.TaskManagement()

    def test_create_face_compare_task(self, task_name, device_name, incidentType):
        allure.dynamic.title(f'create task: {task_name}')
        request_body = get_payload_from_mongo(device_name)
        request_body["taskName"] = task_name
        request_body["deviceTaskConfigs"][0]["zoneId"] = int(sub_zone_id_inited()[0])
        request_body["deviceTaskConfigs"][0]["deviceId"] = query_device_id(device_name)
        request_body["deviceTaskConfigs"][0]["alertFaceConfig"]["libraryIds"][0] = portrait_group_id()[0]
        resp, url = self.TaskManage.add_task(**request_body)
        allure.attach(logging_info(resp, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp["content"][
                   "message"] == "success", f"create {task_name} task failed,\nreason:{resp['content']['message']} "
        time.sleep(30)

    def test_task_alert(self, body_alert, task_name, device_name, incidentType):
        allure.dynamic.title(f'alert with task: {task_name}')
        time.sleep(15)
        request_body = body_alert
        request_body = task_query_alert_config(request_body, query_device_id(device_name), incidentType)
        resp, url = self.TaskManage.query_alert(**request_body)
        allure.attach(logging_info(resp, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp["content"]["data"][
                   "total"] > 0, f"task {task_name} query no alert,\nreason:{resp['content']['message']}"
        allure.attach(pic_url_alert(resp), 'alert', allure.attachment_type.URI_LIST)


