import time
import allure
from testcase.business.function.task_init import *
import pytest
from interface.business import task_management
from utils.query import query_device_id, get_payload_from_mongo

pytestmark = pytest.mark.parametrize('task_name, device_name, incidentType',
                                     [('Face_Body_Recognition', 'face_body', 'OBJECT_PEDESTRIAN')])


@pytest.mark.skipif(condition='Face & Body Recognition' not in get_hard_dog_tasks(),reason='硬狗未授权该任务')
class Test_face_body_attr_task:
    def setup_class(self):
        self.TaskManage = task_management.TaskManagement()

    def test_create_face_body_attr_task(self, task_name, device_name, incidentType):
        allure.dynamic.title(f'create task: {task_name}')
        request_body = get_payload_from_mongo(device_name)
        request_body["taskName"] = task_name
        request_body["deviceTaskConfigs"][0]["zoneId"] = sub_zone_id_inited()[0]
        request_body["deviceTaskConfigs"][0]["deviceId"] = query_device_id(device_name)
        resp, url = self.TaskManage.add_task(**request_body)
        allure.attach(logging_info(resp, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp["content"][
                   "message"] == "success", f"create {task_name} task failed,\nreason:{resp['content']['message']} "
        time.sleep(30)

    def test_face_body_attr_search_center(self, body_attr_search, task_name, device_name, incidentType):
        allure.dynamic.title(f'search with task: {task_name}')
        time.sleep(15)
        request_body = body_attr_search
        request_body = task_attr_query_search_center_config(request_body, query_device_id(device_name), incidentType)
        resp, url = self.TaskManage.query_search_center(**request_body)
        allure.attach(logging_info(resp, url, json.dumps(request_body)), 'log', allure.attachment_type.TEXT)
        assert resp["content"]["data"]["searchList"][0][
                   "total"] > 0, f"task {task_name} search no alert,\nreason:{resp['content']['message']}"
        allure.attach(pic_url_search(resp), 'alert_pic', allure.attachment_type.URI_LIST)
