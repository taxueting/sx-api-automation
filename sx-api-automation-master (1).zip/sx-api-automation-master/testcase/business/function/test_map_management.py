import base64
import random
import pytest
import allure
from pytest_assume.plugin import assume
from config.server_info import map_path
from utils.query import query_payload, mysql_select_one, query_IdList, image_base64
from interface.business import map_management
from task_init import logging_info


class Test_map_management:

    def setup_class(self):
        self.map_base64_code = image_base64(map_path)
        self.request_body_add_zone = query_payload('add_zone')
        self.request_body_map_upload = query_payload('upload_map')
        self.request_body_add_device_to_map = query_payload('add_device_to_map')
        self.request_body_mark_device_on_map = query_payload('mark_device_on_map')
        self.MapManage = map_management.MapManagement()

    @pytest.mark.run(order=10)
    def test_add_sub_zone(self, entire_zone_id):
        request_body_add_zone = self.request_body_add_zone
        request_body_add_zone["parentZoneId"] = entire_zone_id
        resp_add, url_add = self.MapManage.add_zone(**request_body_add_zone)
        assert resp_add["content"][
                   "message"] == "success", f"add sub_zone failed,request body is :{request_body_add_zone},\nreason:{resp_add['content']['message']} "
        allure.attach(logging_info(resp_add, url_add, request_body_add_zone), 'log', allure.attachment_type.TEXT)

    @pytest.fixture(scope='module')
    def sub_zone_id(self):
        sql = "SELECT id  from map_zone mz where name = 'autotest' "
        return mysql_select_one(sql)

    @pytest.mark.run(order=11)
    def test_upload_map_to_sub_zone(self, sub_zone_id):
        request_body_upload_map = self.request_body_map_upload
        request_body_upload_map["zoneId"] = sub_zone_id[0]
        request_body_upload_map["base64Image"] = self.map_base64_code
        resp_upload, url_upload = self.MapManage.upload_map(**request_body_upload_map)
        assert resp_upload["content"][
                   "message"] == "success", f"upload map failed,\nreason:{resp_upload['content']['message']} "
        allure.attach(logging_info(resp_upload, url_upload, request_body_upload_map), 'log', allure.attachment_type.TEXT)

    @pytest.fixture()
    def deviceIdList_format(self):
        deviceIdList = [{"deviceId": device_id, "deviceType": "CAMERA"} for device_id in query_IdList()]
        return deviceIdList

    @pytest.mark.run(order=12)
    def test_device_add_to_map(self, sub_zone_id, deviceIdList_format):
        request_body = self.request_body_add_device_to_map
        request_body["zoneId"] = sub_zone_id[0]
        request_body["deviceIdList"] = deviceIdList_format
        resp, url = self.MapManage.device_add_to_map(sub_zone_id[0], **request_body)
        assert resp["content"][
                   "message"] == "success", f"device add to map failed,request body is :{request_body},\nreason:{resp['content']['message']}"
        allure.attach(logging_info(resp, url, request_body), 'log', allure.attachment_type.TEXT)

    @pytest.fixture()
    def deviceIdList(self):
        return query_IdList()

    @pytest.mark.run(order=13)
    def test_device_mark_on_map(self, deviceIdList, sub_zone_id):
        request_body = self.request_body_mark_device_on_map
        for device_id in deviceIdList:
            request_body["deviceId"] = str(device_id)
            request_body["zoneId"] = str(sub_zone_id[0])
            request_body["vertices"]["x"] = str(random.uniform(0.2, 0.8))
            request_body["vertices"]["y"] = str(random.uniform(0.2, 0.8))
            resp, url = self.MapManage.mark_device(sub_zone_id[0], **request_body)
            assume(resp["content"][
                       "message"] == "success",
                   f"device mark on map failed,request body is :{request_body}\nurl is :{url},\nreason:{resp['content']['message']}")
            allure.attach(logging_info(resp, url, request_body), 'log', allure.attachment_type.TEXT)