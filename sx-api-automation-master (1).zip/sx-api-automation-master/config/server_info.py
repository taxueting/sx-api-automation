import os

# 服务器ip,更换环境时，只需要修改此项
server_ip = ''
server_info = {
    # 服务器连接信息，账号密码一般固定如下
    "host_info": {
        "host": server_ip,
        "user": "root",
        "password": "Goodsense@2021",
    },
    # 视频流地址信息
    "ffserver_info": {
        "host": "10.8.10.26"
    },
    "mongo_db": {
        "mongo_uri": 'mongodb://q4_2v7n2s:oiCimLlEIbb72c1@sh.paas.sensetime.com:32968/sx_auto?authSource=sx_auto&authMechanism=SCRAM-SHA-1',
        "mongo_db_name": 'sx_auto'
    },
    "allure_server": {
        "host": "10.8.10.61", #目前只部署在了61
        "port": 5050,
        "project_id": "sensexperience"
    }
}

file_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "test.conf"))
excel_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "autotest.xlsx"))
map_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "Mytestmap.jpeg"))
mongo_uri = 'mongodb://q4_2v7n2s:oiCimLlEIbb72c1@sh.paas.sensetime.com:32968/sx_auto?authSource=sx_auto&authMechanism=SCRAM-SHA-1'
mongo_db_name = 'sx_auto'
portrait_pic = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "portrait.png"))
body_pic = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "body.png"))
log_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "pytest.log"))
