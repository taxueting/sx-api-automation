from config.server_info import server_ip
from utils.query_server_info import query_server_info

# 数据库链接信息，自动获取，不需要修改
oc_sql_passwd = {"10.198.67.80": "M2FO8m7H3H40tgH",
                 "10.211.41.68": "j5gClGhtBk7tPdF"}

if server_ip in oc_sql_passwd.keys():
    sql_info = {
        "host": server_ip,
        "port": 30398,
        "user": "root",
        "password": oc_sql_passwd[server_ip],
        "database": "sensexplorer"
    }
else:
    sql_info = {
        "host": server_ip,
        "port": 30398,
        "user": "root",
        "password": query_server_info()[0],
        "database": "sensexplorer"
    }
