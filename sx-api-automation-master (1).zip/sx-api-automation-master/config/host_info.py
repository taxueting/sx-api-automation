from utils.query import query_root_user_info
from utils.query_server_info import query_server_info
from config.server_info import server_ip

# 环境接口请求地址，及请求头
oc_url = {"10.198.67.80":"http://web-app.oc-80.xplorer.sensetime.com",
          "10.211.41.68":"http://web-app.www.sxperience.sensetime.com"}
if server_ip in oc_url.keys():
    host_info_url = oc_url[server_ip]
else:
    host_info_url = 'http://web-app.'+query_server_info()[1]
host_info_header = {
            "content-type": "application/json",
            "tenantid": query_root_user_info()[1],
            "userid": str(query_root_user_info()[0]),
            "accept-language": "en-US"
        }