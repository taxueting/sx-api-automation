business_path = {
    "DeviceManagement": {
        "device_group_add": "/api/camera-device-management/api/v1/device-groups",
        "device_add": "/api/camera-device-management/api/v1/devices",
        "delete_device_group":"/api/camera-device-management/api/v1/device-groups/{}"
    },
    "TaskManagement": {
        "face_attribute_add": "/api/task-management/api/v1/task/createTask",
        "face_attribute_query": "/api/timedb-management/api/v1/search/query/attributesSearch",
        "task_add": "/api/task-management/api/v1/task/createTask",
        "task_delete": "/api/task-management/api/v1/task/{}",
        "query_alert": "/api/incident-record-management/api/v1/incident/records",
        "query_search_center": "/api/timedb-management/api/v1/search/query/search",
        "hard_dog": "/api/user-management/api/v1/ums/role/user/permissions"
    },
    "MapManagement": {
        "add_zone": "/api/map-management/api/v1/map/zone/addZone",
        "map_upload": "/api/map-management/api/v1/map/upload",
        "device_add_to_map": "/api/map-management/api/v1/map/device/{}",
        "mark_device_on_map": "/api/map-management/api/v1/map/device/mark/{}",
        "delete_map_zone": "/api/map-management/api/v1/map/zone/{}"
    },
    "PortraitManagement": {
        "add_portrait_group": "/api/portrait-management/api/v1/portraitlib/add",
        "add_portrait": "/api/portrait-management/api/v1/portrait/add",
        "add_body_group": "/api/portrait-management/api/v1/bodylib/add",
        "add_body": "/api/portrait-management/api/v1/portraitbody/add",
        "add_vehicle_group": "/api/portrait-management/api/v1/automobilelib/add",
        "add_vehicle": "/api/portrait-management/api/v1/automobile/add",
        "delete_portrait_group":"/api/portrait-management/api/v1/portraitlib/{}",
        "delete_body_group":"/api/portrait-management/api/v1/bodylib/{}",
        "delete_vehicle_group":"/api/portrait-management/api/v1/automobilelib/delete/{}"
    }
}
