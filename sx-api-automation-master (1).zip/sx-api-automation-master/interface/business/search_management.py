import datetime
import time

import jsonpath as jsonpath

from config.business.url import business_path
from config.host_info import host_info_url, host_info_header
from config.server_info import server_info
from utils.mongodb import MongoDb
from utils.request import Request
from utils.mysql import Mysql
from utils.query import query_device_id, query_payload

path = business_path.get('TaskManagement')
url = host_info_url + path.get("query_search_center")
header = host_info_header
search_info_data = query_payload('search_info_data')
device_name = query_payload('device_name')
mongodb_data_type = query_payload('mongodb_data_type')
data = search_info_data


def get_total_page():
    """
    获取总页数的函数
    :return: 总页数
    """
    data["deviceIdList"] = get_ids()
    data['dateEnd'] = get_end_time()
    data['dateStart'] = get_start_time()
    resp = Request(method="POST", url=url, headers=header,
                   json_data=data).request()
    total_page = jsonpath.jsonpath(resp, "$..totalPage")[0]
    return total_page


def get_all_data():
    """
    获取页面所有数据，注意每页是有图片的url的，
    :return: 它的返回值格式是[[{},url],[{},{},url],[{},{},url]]，内层每个[],代表一辆车;内层[]中的每个{},代表每个车牌
    """
    total_page = get_total_page()
    total_data = []
    print(get_start_time() + "-" + get_end_time())
    print("获取到的总页数是:{}页".format(total_page))
    for page in range(1, total_page + 1):
        data['page'] = page
        if page == 1:
            print()
        print("正在获取第{}页的数据".format(page))
        time.sleep(3)  # 61环境有频率控制
        resp = Request(method="POST", url=url, headers=header, json_data=data).request()
        time.sleep(3)
        tmp_plateNos = jsonpath.jsonpath(resp, "$..plateNos")  # 45环境响应的属性是plateNos
        # tmp_plateNos = jsonpath.jsonpath(resp, "$..plateAttributes") # 61环境响应属性有变
        tmp2_captureUrl = jsonpath.jsonpath(resp, "$..captureUrl")
        for index, value in enumerate(tmp_plateNos):
            if value == [] or value is None:
                continue
            else:
                tmp_plate = tmp_plateNos[index]
                tmp_plate.append(tmp2_captureUrl[index])
                total_data.append(tmp_plate)
    return total_data


def format_scrapy_data(lists=None):
    """
    解析爬取到的车牌
    :param lists: 传递的是爬取到的车牌，格式为[[{},url],[{},{},url],[{},{},url]]
    :return: 返回的是格式化后的车牌,它将一个车牌、两个车牌、三个车牌的分开了
    """
    if lists is None:
        return
    one_pt = []
    two_pt = []
    three_pt = []
    for plate in lists:
        plate = plate[:-1]
        length = len(plate)
        if length == 1:
            one_pt.append(parse_plate(plate))
        if length == 2:
            two_pt.append(parse_plate(plate))
        if length == 3:
            three_pt.append(parse_plate(plate))
    return one_pt, two_pt, three_pt


def parse_plate(lists=None):
    """
    解析每一辆车
    :param lists: 格式为[{},{}]
    :return: 返回值为list,格式为[车牌1，车牌2]
    """
    tmp = []
    for value in lists:
        tmp.append(value.get('value'))
    return tmp


def get_all_data_from_mongo(device_name=device_name):
    """
    从mongo数据库取数据
    :param device_name: 可以传递device_name;如果不传，那么获取的是所有数据，结果是一个列表
    :return:
    """
    database = MongoDb(server_info.get('mongo_db')["mongo_uri"])
    db = database.connect_db(server_info.get('mongo_db')["mongo_db_name"])
    table = db["sx_ground_truth"]
    flag = bool(device_name)
    if flag:
        condition = {'video_name': device_name, 'type': mongodb_data_type}
        data = table.find_one(condition)
        return [data]
    else:
        result = table.find({'type': mongodb_data_type})
        data = []
        for item in result:
            data.append(item)
        return data


def get_mongo_gt():
    """从mongo里如果不传设备名，那么获取到所有gt值；如果传了就能获取到当前设备gt值"""
    gt_plates = []
    for data in get_all_data_from_mongo():
        gt_plates.extend(data.get('gt'))
    return gt_plates


def format_mongo_data():
    """
    格式化mongo数据
    :param lists:
    :return:
    """
    lists = get_mongo_gt()
    one_lists = []
    two_lists = []
    three_lists = []
    for value in lists:
        length = len(value)
        if length == 1:
            tmp = [value[0]]
            one_lists.append(tmp)
        elif length == 2:
            two_lists.append(value)
        elif length == 3:
            three_lists.append(value)
    return one_lists, two_lists, three_lists


def get_device_name():
    """获取设备名"""
    device_names = [data.get('video_name') for data in get_all_data_from_mongo()]
    durations = [data.get('duration') for data in get_all_data_from_mongo()]
    max_duration_index = durations.index(max(durations))
    device_name = (device_names[max_duration_index])
    return device_name


def get_ids():
    """获取设备ids"""
    device_names = [data.get('video_name') for data in get_all_data_from_mongo()]
    ids = [query_device_id(device_name) for device_name in device_names]
    return ids


def get_end_time():
    """获取最大duration的对应的设备的结束时间"""
    durations = [data.get('duration') for data in get_all_data_from_mongo()]
    startime = datetime.datetime.strptime(get_start_time(), '%Y-%m-%d %H:%M:%S')
    endtime = startime + datetime.timedelta(minutes=+(max(durations) + 5))
    return datetime.datetime.strftime(endtime, '%Y-%m-%d %H:%M:%S')


def get_start_time():
    """获取最大duration的对应的设备的开始时间"""
    device_name = get_device_name()
    sql = f"SELECT create_time  from biz_task WHERE task_name = '{device_name}'"
    with Mysql() as mysql:
        create_date = mysql.select_one(sql=sql)[0]
    return datetime.datetime.strftime(create_date, '%Y-%m-%d %H:%M:%S')


def compare_two_list_plates(plates_gt, plates_pt):
    """比较两个相同类型的车牌"""
    count = 0
    for data1 in plates_gt:
        for data2 in plates_pt:
            if set(data1).issubset(set(data2)):
                count += 1
                break
    return count


if __name__ == '__main__':
    # print(get_total_page())
    # print(get_all_data())
    one_gt, two_gt, three_gt = format_mongo_data()
    print(len(one_gt))
    print(len(two_gt))
    print(len(three_gt))
    # one_pt, two_pt, three_pt = format_scrapy_data(get_all_data())
    # print(one_pt)
    # print(two_pt)
    # print(three_pt)
    # print(len(one_pt))
    # print(len(two_pt))
    # print(len(three_pt))
    # print(compare_two_list_plates(one_gt, one_pt))
    # print(compare_two_list_plates(two_gt, two_pt))
    # print(compare_two_list_plates(three_gt, three_pt))
    # print(get_all_data())
