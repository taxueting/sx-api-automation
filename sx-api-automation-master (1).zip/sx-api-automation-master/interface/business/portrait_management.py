from config.host_info import host_info_url, host_info_header
from config.business.url import business_path
from utils.request import Request


class PortraitManagement:
    def __init__(self):
        self.url = host_info_url
        self.header = host_info_header
        self.path = business_path.get('PortraitManagement')

    def add_portrait_group(self, **request_body):
        url = self.url + self.path.get("add_portrait_group")
        resp = Request(method="POST", url=url, headers=self.header,
                       json_data=request_body).request()
        return resp, url

    def add_body_group(self, **request_body):
        url = self.url + self.path.get("add_body_group")
        resp = Request(method="POST", url=url, headers=self.header,
                       json_data=request_body).request()
        return resp, url

    def add_vehicle_group(self, **request_body):
        url = self.url + self.path.get("add_vehicle_group")
        resp = Request(method="POST", url=url, headers=self.header,
                       json_data=request_body).request()
        return resp, url

    def add_portrait(self, **request_body):
        url = self.url + self.path.get("add_portrait")
        resp = Request(method="POST", url=url, headers=self.header,
                       json_data=request_body).request()
        return resp, url

    def add_body(self, **request_body):
        url = self.url + self.path.get("add_body")
        resp = Request(method="POST", url=url, headers=self.header,
                       json_data=request_body).request()
        return resp, url

    def add_vehicle(self, **request_body):
        url = self.url + self.path.get("add_vehicle")
        resp = Request(method="POST", url=url, headers=self.header,
                       json_data=request_body).request()
        return resp, url

    def delete_portrait_group(self, group_id):
        url = self.url + self.path.get("delete_portrait_group").format(group_id)
        resp = Request(method="DELETE", url=url, headers=self.header, ).request()
        return resp, url

    def delete_body_group(self, group_id):
        url = self.url + self.path.get("delete_body_group").format(group_id)
        resp = Request(method="DELETE", url=url, headers=self.header, ).request()
        return resp, url

    def delete_vehicle_group(self, group_id):
        url = self.url + self.path.get("delete_vehicle_group").format(group_id)
        resp = Request(method="DELETE", url=url, headers=self.header, ).request()
        return resp, url
