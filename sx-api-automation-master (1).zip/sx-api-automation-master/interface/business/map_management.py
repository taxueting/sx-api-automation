from config.host_info import host_info_url, host_info_header
from config.business.url import business_path
from utils.request import Request


class MapManagement:
    def __init__(self):
        self.url = host_info_url
        self.header = host_info_header
        self.path = business_path.get('MapManagement')

    def add_zone(self, **request_body):
        url = self.url + self.path.get("add_zone")
        resp = Request(method="PUT", url=url, headers=self.header,
                       json_data=request_body).request()
        return resp, url

    def upload_map(self, **request_body):
        """
        :param request_body:
        :return:
        """
        url = self.url + self.path.get("map_upload")
        resp = Request(method="POST", url=url, headers=self.header,
                       json_data=request_body).request()
        return resp, url

    def device_add_to_map(self, zone_id, **request_body):
        url = self.url + self.path.get("device_add_to_map").format(zone_id)
        resp = Request(method="PUT", url=url, headers=self.header,
                       json_data=request_body).request()
        return resp, url

    def mark_device(self, zone_id, **request_body):
        url = self.url + self.path.get("mark_device_on_map").format(zone_id)
        resp = Request(method="POST", url=url, headers=self.header,
                       json_data=request_body).request()
        return resp, url

    def delete_map_zone(self, zone_id):
        url = self.url + self.path.get("delete_map_zone").format(zone_id)
        resp = Request(method="DELETE", url=url, headers=self.header).request()
        return resp, url
