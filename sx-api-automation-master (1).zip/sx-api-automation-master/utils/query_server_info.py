from config.server_info import server_ip
from utils.ssh import SSH
import base64


def query_server_info():
    host = server_ip
    user = "root"
    password = "Goodsense@2021"
    ssh = SSH(host, user, password)
    ssh.conn()
    get_tidb_password = "kubectl get secrets password-secrets -o yaml | grep tidb_root_password | awk '{print $2}' "
    get_host_url = "kubectl get ingress.|grep business|awk '{print $3}'"
    password = ssh.run_cmd(get_tidb_password)
    password = base64.b64decode(str(password).encode('utf-8')).decode()
    host_url = ssh.run_cmd(get_host_url)
    ssh.close()
    return password, host_url[0]
