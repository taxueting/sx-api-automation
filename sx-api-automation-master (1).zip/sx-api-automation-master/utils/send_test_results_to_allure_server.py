import sys
sys.path.append(".")
import os, requests, json, base64
from config.server_info import server_info


def send_test_results_to_allure_server():
    allure_server_info = server_info.get('allure_server')
    allure_server = f'http://{allure_server_info["host"]}:{allure_server_info["port"]}'
    project_id = allure_server_info["project_id"]
    allure_results_directory = "/reports"
    current_directory = os.path.dirname(os.path.realpath('__file__'))
    results_directory = current_directory + allure_results_directory
    print('RESULTS DIRECTORY PATH: ' + results_directory)
    files = os.listdir(results_directory)
    results = []
    for file in files:
        result = {}
        file_path = results_directory + "/" + file
        if os.path.isfile(file_path):
            try:
                with open(file_path, "rb") as f:
                    content = f.read()
                    if content.strip():
                        b64_content = base64.b64encode(content)
                        result['file_name'] = file
                        result['content_base64'] = b64_content.decode('UTF-8')
                        results.append(result)
                    else:
                        print('Empty File skipped: '+ file_path)
            finally :
                f.close()
        else:
            print('Directory skipped: '+ file_path)

    headers = {'Content-type': 'application/json'}
    request_body = {
        "results": results
    }

    print("------------------SEND-RESULTS------------------")
    response = requests.post(f"{allure_server}/allure-docker-service/send-results?project_id={project_id}&force_project_creation=true", headers=headers, json=request_body, verify=True)
    assert response.status_code == 200, f'STATUS CODE AND RESPONSE:{response.status_code}, {json.dumps(response.json(), indent=4, sort_keys=True)}'

    print("------------------GENERATE-REPORT------------------")
    response = requests.get(f'{allure_server}/allure-docker-service/generate-report?project_id={project_id}&execution_name=&execution_from=&execution_type=', headers=headers, verify=True)
    assert response.status_code == 200, f'STATUS CODE AND RESPONSE:{response.status_code}, {json.dumps(response.json(), indent=4, sort_keys=True)}'    
    print(f'ALLURE REPORT URL: {response.json()["data"]["report_url"]}')

if __name__ == "__main__":
    send_test_results_to_allure_server()
   


