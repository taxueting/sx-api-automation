import os
import time
import boto.s3.connection


class oss:
    def __init__(self):
        USESIGV4 = False
        osshost = 'oss-sh2.sensetime.com'
        ossport = 443
        accesskey = 'TD4RTBCLNJBFFGT2J104'
        secretkey = 'mbZGNdKQKRpSp8OPOYcGAFBGzq9joKA5pXYiln0C'
        if USESIGV4:
            os.environ['S3_USE_SIGV4'] = 'True'
        self.conn = boto.connect_s3(
            aws_access_key_id=accesskey,
            aws_secret_access_key=secretkey,
            host=osshost,
            port=ossport,
            # is_secure=False,
            calling_format=boto.s3.connection.OrdinaryCallingFormat(),
        )
        if USESIGV4:
            self.conn.auth_region_name = ''

    # 列举Bucket
    def list_buckets(self):
        for bucket in self.conn.get_all_buckets():
            print("{name}\t{created}".format(
                name=bucket.name,
                created=bucket.creation_date,
            ))

    # 列举对象
    def list_objects(self, bucketname, prefix=''):
        print('listobjects---------name=%s, prefix=%s' % (bucketname, prefix))
        bucket = self.conn.get_bucket(bucketname)
        list_name = []
        for key in bucket.list(prefix):
            list_name.append(key.name)
        return list_name

    # 下载对象
    def downloadObjectToFile(self, bucketname, objname, dstFile):
        start_time = time.time()
        print('downloadObjectToFile---- time=%s, bucket=%s, object=%s, file=%s' % (
            time.asctime(), bucketname, objname, dstFile))
        try:
            bucket = self.conn.get_bucket(bucketname)
            key = bucket.get_key(objname)
            key.get_contents_to_filename(dstFile)
            end_time = time.time()
            print("download completed!，cost time:{}".format(end_time - start_time))
        except Exception as e:
            print("t exception:", e)

    def down_all_videos(self, bucketname):
        video_list = oss().list_objects(bucketname)
        dst_dir = os.getcwd()
        for video in video_list:
            if not os.path.exists(os.path.dirname(dst_dir + '/' + video)):
                os.makedirs(os.path.dirname(dst_dir + '/' + video))
            else:
                self.downloadObjectToFile(bucketname, video, dst_dir + '/' + video)


if __name__ == "__main__":
    bucket = "sensexplorer-oss-file-20230202"
    oss().down_all_videos(bucket)
