import os
import datetime
import base64
from utils.mongodb import MongoDb
from utils.mysql import Mysql
from config.server_info import excel_path, server_info
from openpyxl import load_workbook


def image_base64(image_path):
    with open(image_path, 'rb') as f:
        return 'data:image/jpeg;base64,' + base64.b64encode(f.read()).decode('utf-8')


# 查询数据库tidb密码 & host_url


# 查询设备信息
def query_device_info():
    sql = 'SELECT device_name from info_device'
    with Mysql() as mysql:
        query_result = mysql.select_all(sql)
    list_name = []
    for query_name in query_result:
        list_name.append(query_name[0].decode())
    return list_name


# 获取自动化组设备下的运行任务
def delete_task():
    sql = "SELECT task_id  from device_task_config  where device_id in (SELECT device_id  from info_device where " \
          "group_id =(SELECT group_id from info_device_group where name = 'autotest')) "
    with Mysql() as mysql:
        query_result = mysql.select_all(sql)
    list_name = []
    for query_name in query_result:
        list_name.append(query_name[0])
    return list_name


# 根据任务id查任务名称
def query_task_name(task_id):
    sql = f"SELECT task_name from biz_task bt where task_id ={task_id}"
    with Mysql() as mysql:
        query_result = mysql.select_one(sql)
    return query_result[0].decode()


# 根据设备名称查询设备id
def query_device_id(device_name):
    sql = f"SELECT device_id  from info_device where device_name ='{device_name}'"
    with Mysql() as mysql:
        query_result = mysql.select_one(sql)
    return query_result[0]


# 获取目录下子目录名称
def query_dirs(root_dir):
    for parent, dir_names, filenames in os.walk(root_dir):
        return dir_names


# 获取目录下子文件名称
def query_files(root_dir):
    for parent, dir_names, filenames in os.walk(root_dir):
        print(filenames)


# 读取test.conf文件并输出文件名
def read_config(file_path):
    f = open(file_path, 'r', encoding='UTF-8')
    list_videos = []
    for i in f:
        if i[0:7] == '<Stream':
            list_videos.append(i.split('<Stream ')[1].split('>\n')[0])
        else:
            pass
    return list_videos


# 查询用户id与租户id
def query_root_user_info():
    sql = "SELECT user_id ,tenant_id  from user where type='TENANT_ADMIN' and name = 'sxtest'"
    with Mysql() as mysql:
        query_result = mysql.select_one(sql)
    return [query_result[0], query_result[1].decode()]


# 通过task_name检索对应的传参json
def query_payload(task_name):
    file_path = excel_path
    wb = load_workbook(file_path)
    sheet = wb.active
    col_A = sheet['A']
    for cell in col_A:
        if cell.value == f'{task_name}':
            value_right = sheet.cell(row=cell.row, column=cell.column + 1).value
            return eval(value_right)
        else:
            pass


# 通过设备id检索task_id
def query_task_id(device_id):
    sql = f"SELECT task_id from device_task_config where device_id ={device_id} "
    with Mysql() as mysql:
        query_result = mysql.select_one(sql)
    return query_result[0]


# 查询总园区地图id
def query_entire_zone_id():
    sql = "SELECT id  from map_zone mz where parent_id =0 "
    with Mysql() as mysql:
        query_result = mysql.select_one(sql)
    return query_result[0]


def mysql_select_one(sql):
    with Mysql() as mysql:
        query_result = mysql.select_one(sql)
    return query_result


def query_IdList():
    sql = "SELECT device_id  from info_device where group_id =(SELECT group_id  from info_device_group where name " \
          "='autotest') "
    with Mysql() as mysql:
        query_result = mysql.select_all(sql)
    IdList = [query_name[0] for query_name in query_result]
    return IdList



def delete_device(device_id):
    sql = f"DELETE from info_device where device_id ={device_id}"
    with Mysql() as mysql:
        mysql.delete(sql)




def get_payload_from_mongo(device_name):
    database = MongoDb(server_info.get('mongo_db')["mongo_uri"])
    db = database.connect_db(server_info.get('mongo_db')["mongo_db_name"])
    table = db["sx_videos_config"]
    document = table.find_one({"video_name": f"{device_name}"})
    return document["task_config_template"]


def date_range():
    date_start = (datetime.datetime.now() - datetime.timedelta(minutes=5)).strftime('%Y-%m-%d %H:%M:%S')
    date_end = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return date_start, date_end

