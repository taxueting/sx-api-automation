import pytest
import os
from config import server_info

if __name__ == "__main__":
    ip_list = ['10.198.67.80','10.8.10.61']
    for dst_ip in ip_list:
        try:
            server_info.server_ip = dst_ip
            pytest.main(['-vs','./testcase/business/function/', '--alluredir', './reports'])
            os.system('python3 "./utils/send_test_results_to_allure_server.py"')
            os.system("rm -rf ./reports/*")
        except Exception as e:
            print(e)